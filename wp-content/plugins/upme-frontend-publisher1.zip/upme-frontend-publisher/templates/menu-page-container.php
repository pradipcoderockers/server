<?php 
    global $upfp_settings_data; 
    extract($upfp_settings_data);
?>

<div class="wrap">
    <?php echo $tabs; ?>
    <?php echo $tab_content; ?>

</div>

